extends CharacterBody2D




func _on_butoes_4_body_entered(_body: Node2D) -> void:
	$CollisionShape2D.position.y = 1000
	visible = false


func _on_butoes_4_body_exited(_body: Node2D) -> void:
	$CollisionShape2D.position.y = 0
	visible = true
