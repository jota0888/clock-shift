extends Area2D

@export var nun = 0

func _on_body_entered(body: Node2D) -> void:
	if body.name == "player":
		body.check = nun
