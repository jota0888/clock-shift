extends CharacterBody2D
class_name Crate

const SPEED = 170


func _physics_process(delta: float) -> void:
	grav(delta)
	move_and_slide()
	velocity.x = 0
	
func slide(dir):
	velocity.x = int(dir.x) * SPEED

func grav(delta):
	if is_on_floor():
		velocity.y = 0
	else:
		velocity += get_gravity() * delta
