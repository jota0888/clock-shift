extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(_delta: float) -> void:
	rotation += 0.06


func _on_body_entered(body: Node2D) -> void:
	if body.name == "player":
		body.gear += 1
		queue_free()
