extends CharacterBody2D

@onready var controls: CanvasLayer = $"../controls"
@onready var coyote: Timer = $coyote

var check = 0
var gear = 0

const SPEED = 300.0
const JUMP_VELOCITY = -275.0
var dia = 1
var can_jump = true

func _ready() -> void:
	controls.visible = true
	get_parent().get_node("noite").enabled = false

func _physics_process(delta: float) -> void:
	if gear == 6:
		get_tree().change_scene_to_file("res://scenes/end.tscn")
	sound_handler()
	checkpoint_handler()
	move(delta)
	mudanca()
	animation_handler()
	crate_push()
	move_and_slide()

func move(delta):
	if not is_on_floor():
		velocity += get_gravity() * delta
	if Input.is_action_just_pressed("jump") and can_jump:
		velocity.y = JUMP_VELOCITY
	if is_on_floor() and !can_jump:
		can_jump = true
	elif can_jump and coyote.is_stopped():
		coyote.start()
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

func mudanca():
	if Input.is_action_just_pressed("shift") and $"shift coldown".is_stopped():
		dia = -dia
		$"shift coldown".start()
		Juicee.flash(get_parent().get_node("background"), Color(1,1,1),0.30)
		Juicee.glitch(self, 1.5, 1.5)
		if dia == -1:
			Juicee.impact_ring(self, Color(0.031, 0.031, 1.0, 1.0), 0)
			Juicee.burst(self, 12, Color(0.031, 0.031, 1.0, 1.0), 180)
		else:
			Juicee.impact_ring(self, Color(1.0, 0.843, 0.263, 1.0))
			Juicee.burst(self, 12, Color(1.0, 0.843, 0.263, 1.0), 180)
	if dia == 1:
		get_parent().get_node("background").frame = 0
		get_parent().get_node("noite").enabled = false
		get_parent().get_node("dia").enabled = true
	else:
		get_parent().get_node("background").frame = 1
		get_parent().get_node("noite").enabled = true
		get_parent().get_node("dia").enabled = false

func animation_handler():
	if Input.is_action_just_pressed("jump"):
		pass
	elif Input.is_action_pressed("left"):
		@warning_ignore("int_as_enum_without_cast")
		Juicee.flip(self, 1)
		$AnimatedSprite2D.play("walk")
	elif Input.is_action_pressed("right"):
		@warning_ignore("int_as_enum_without_cast")
		Juicee.flip(self, 2)
		$AnimatedSprite2D.play("walk")
	else:
		$AnimatedSprite2D.play("idle")

func crate_push():
	for Objects in get_slide_collision_count():
		var collision = get_slide_collision(Objects)
		if collision.get_collider() is Crate:
			collision.get_collider().slide(-collision.get_normal())

func _on_coyote_timeout() -> void:
	can_jump = false

func _debug(_body: Node2D) -> void:
	dia = -dia
	print("debug")

func sound_handler():
	if Input.is_action_just_pressed("jump") and is_on_floor():
		$jump.play()
	if Input.is_action_just_pressed("shift"):
		$tictac.play()
		$tic.start()

func checkpoint_handler():
	if Input.is_action_just_pressed("restart"):
		Juicee.glitch(self, 1.5, 1)
		if check == 0:
			get_tree().reload_current_scene()
		if check == 1:
			position.x = 464
			position.y = -32
			$"../caixas/crate".position.x = 51
			$"../caixas/crate".position.y = -79
		if check == 2:
			position.x = 464
			position.y = -320
		if check == 3:
			position.x = 176
			position.y = -768
			$"../caixas/crate2".position.x = 416
			$"../caixas/crate2".position.y = -744
		if check == 4:
			position.x = 112
			position.y = -1152
			$"../caixas/crate3".position.x = 480
			$"../caixas/crate3".position.y = -1136
		if check == 5:
			position.x = 144
			position.y = -1440
			$"../caixas/crate4".position.x = 480
			$"../caixas/crate4".position.y = -1584
		if check == 6:
			position.x = 208
			position.y = -1696
			$"../caixas/crate5".position.x = 368
			$"../caixas/crate5".position.y = -1664
			$"../caixas/crate6".position.x = 560
			$"../caixas/crate6".position.y = -1832

func _tic() -> void:
	$tictac.stop()
